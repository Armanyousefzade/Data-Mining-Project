/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package createdistancematrix;

public class Accident {

    String ReferenceNumber;
    String GridRefEasting;
    String GridRefNorthing;
    int NumberofVehicles;
    String AccidentDate;
    String Time24hr;
    String RoadClass;
    String RoadSurface;
    String LightingConditions;
    String WeatherConditions;
    String CasualtyClass;
    String CasualtySeverity;
    String SexofCasualty;
    int AgeofCasualty;
    String TypeofVehicle;
    String DayofWeek;
    int HolidayOrWeekend;
    String Timenominal;
    String Season;
    String ageOfCasualtyNominal;
}
